import "./App.css";
import { Button, Form, FormGroup, Container, Card } from "react-bootstrap";
import { useState } from "react";

function Home({ inputValue, handleSubmit, handleChange }) {
  return (
    <div className="m-5 pb-5">
      <Container style={{ width: "50%", border: "3px solid grey" }}>
        <Form onSubmit={handleSubmit} className="m-5">
          <FormGroup>
            <Form.Label>GitHub username:</Form.Label>
            <Form.Control
              size="lg"
              className="text-center"
              type="text"
              placeholder="e.g. facebook"
              onChange={handleChange}
            />
          </FormGroup>
          <br />
          <br />
          <Button
            type="submit"
            className="btn btn-lg"
            variant="secondary"
            style={{ width: "100%" }}
          >
            GO!
          </Button>
        </Form>
      </Container>
    </div>
  );
}

function Item({ name, bio, avatar_url, location, created_at, type}) {
  return (
    <ul style={{ listStyleType: "none" }}>
      <li><img src={avatar_url} width="80px" border-radius="20px"/></li>
      <li><h3>{name}</h3></li>
      <li>{bio}</li>
      <li>{created_at} | Located in {location} | <a href="http://giphy.com">http://giphy.com</a></li>
      {/* <li></li>
      <li></li> */}
      <li>{type}</li>
    </ul>
  );
}

function Repo({blog, full_name, location, bio, created_at, type, description}) {
  return(
    <ul style={{ listStyleType: "none" }}>
      <li>{location}</li>
      <li>{blog}</li>
      <li>{full_name}</li>
      <li>{bio}</li>
      <li>{created_at}</li>
      <li>{type}</li>
      <li>{description}</li>
    </ul>
  );
}

function App() {
  const [inputValue, setInputValue] = useState("");
  const [dataFromApi, setDataFromApi] = useState("");
  const [repos, setRepos] = useState([]);
  const handleSubmit = (e) => {
    e.preventDefault();

    try {
      fetch(`https://api.github.com/users/${inputValue}`)
        .then((res) => res.json())
        .then((data) => setDataFromApi(data));
      // .then((data) => console.log(data));
    } catch (error) {
      console.error("Error fetching data:", error);
    }

    try {
      fetch(`https://api.github.com/users/${inputValue}/repos`)
        .then((res) => res.json())
        .then((data) => setRepos(data));
      // .then((data) => console.log(data));
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleChange = (e) => {
    setInputValue(e.target.value);
  };
  return (
    <div>
      <Home
        inputValue={inputValue}
        handleChange={handleChange}
        handleSubmit={handleSubmit}
      />
      
        
        <Item
          avatar_url={dataFromApi.avatar_url}
          blog={dataFromApi.blog}
          name={dataFromApi.name}
          bio={dataFromApi.bio}
          location={dataFromApi.location}
          created_at={dataFromApi.created_at}
          type={dataFromApi.type}
          key={dataFromApi.id}
        />
      {
        repos?.map((item) => (
          <Repo
            avatar_url={item.avatar_url}
            full_name={item.full_name}
            login={item.bio}
            location={item.location}
            description={item.description}
            type={item.type}
            key={item.id}
            created_at={item.created_at}
          />
      ))}
    </div>
  );
}

export default App;

